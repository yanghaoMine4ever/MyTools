package com.sf.fw.x5.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Configuration
public class AddSignGatewayConfig {

    public static final Logger logger = LoggerFactory.getLogger(AddSignGatewayConfig.class);

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static final String PREFIX_REQ = "req=";

    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("x5app", r -> r.path("/sb/*")
                        .filters(f -> f.modifyRequestBody(String.class, String.class, MediaType.APPLICATION_FORM_URLENCODED_VALUE,
                                (exchange, s) -> {
                                    if (!Objects.equals(exchange.getRequest().getMethod(), HttpMethod.POST)
                                    || !StringUtils.hasLength(s)) {
                                        return Mono.just(s);
                                    }
                                    String src = decode(s);
                                    logger.info("原始请求参数：{}", src);
                                    String reqJson = src.replaceFirst(PREFIX_REQ, "");
                                    ClientInfo clientInfo = fromJson(reqJson, ClientInfo.class);
                                    addSign(clientInfo);
                                    String signJson = toJson(clientInfo);
                                    return Mono.just(signJson);
                                }))
                        .uri("http://localhost:80"))
                .build();
    }

    private void addSign(ClientInfo clientInfo) {
        if (clientInfo == null) {
            return ;
        }
        clientInfo.setSign("12332112345657");
    }

    private <T> T fromJson(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            logger.error("json format error", e);
        }
        return null;
    }

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error("json format error", e);
        }
        return "";
    }

    private String decode(String src) {
        try {
            return URLDecoder.decode(src, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("decode error", e);
        }
        return "";
    }

    private String nodeToString(Object node) {
        return node == null ? "" : node.toString();
    }

    static class ClientInfo {
        private Integer clientVersion;
        private String token;
        private JsonNode requstData;
        private ArrayNode requstDataList;
        private String ClientTime;
        private String sign;

        public Integer getClientVersion() {
            return clientVersion;
        }

        public void setClientVersion(Integer clientVersion) {
            this.clientVersion = clientVersion;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public JsonNode getRequstData() {
            return requstData;
        }

        public void setRequstData(JsonNode requstData) {
            this.requstData = requstData;
        }

        public ArrayNode getRequstDataList() {
            return requstDataList;
        }

        public void setRequstDataList(ArrayNode requstDataList) {
            this.requstDataList = requstDataList;
        }

        public String getClientTime() {
            return ClientTime;
        }

        public void setClientTime(String clientTime) {
            ClientTime = clientTime;
        }

        public String getSign() {
            return sign;
        }

        public void setSign(String sign) {
            this.sign = sign;
        }

        @Override
        public String toString() {
            return "ClientInfo{" +
                    "clientVersion=" + clientVersion +
                    ", token='" + token + '\'' +
                    ", requstData=" + requstData +
                    ", requstDataList=" + requstDataList +
                    ", ClientTime='" + ClientTime + '\'' +
                    ", sign='" + sign + '\'' +
                    '}';
        }
    }

}
